﻿Public Class frmMain

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Me.Size = New Size(490, 335) ' reszie the window, display the output 
        If (Val(tBoxHoursWorked.Text) > 0 And Val(tBoxRatePay.Text) > 0) Then ' check the wrong data like not number or the number less then 1
            'calculate the value 
            labGrossPay.Text = Val(tBoxHoursWorked.Text) * Val(tBoxRatePay.Text)
            labFWT.Text = Val(labGrossPay.Text) * 0.2
            labFICA.Text = Val(labGrossPay.Text) * 0.08
            labIncomeTax.Text = Val(labGrossPay.Text) * 0.03
            labNetPay.Text = Val(labGrossPay.Text) - Val(labFWT.Text) - Val(labFICA.Text) - Val(labIncomeTax.Text)
            labGrossPay.Text = Format(labGrossPay.Text, "Currency")
            labFWT.Text = Format(labFWT.Text, "Currency")
            labFICA.Text = Format(labFICA.Text, "Currency")
            labIncomeTax.Text = Format(labIncomeTax.Text, "Currency")
            labNetPay.Text = Format(labNetPay.Text, "Currency")
        Else ' invalid data
            tBoxHoursWorked.Text = String.Empty
            tBoxRatePay.Text = String.Empty
            labGrossPay.Text = String.Empty
            labFWT.Text = String.Empty
            labFICA.Text = String.Empty
            labIncomeTax.Text = String.Empty
            labNetPay.Text = String.Empty
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tBoxEmployeeName.Text = String.Empty
        tBoxHoursWorked.Text = String.Empty
        tBoxRatePay.Text = String.Empty
        labGrossPay.Text = String.Empty
        labFWT.Text = String.Empty
        labFICA.Text = String.Empty
        labIncomeTax.Text = String.Empty
        labNetPay.Text = String.Empty
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Size = New Size(260, 335) 'init window size
    End Sub
End Class
