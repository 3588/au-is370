﻿Public Class Form1
    Private Sub TextBox1_Enter(sender As Object, e As EventArgs) Handles TextBox1.Enter
        TextBox1.SelectAll()
        labUsed.Text = String.Empty
        labCharge.Text = String.Empty
    End Sub
    Private Sub TextBox2_Enter(sender As Object, e As EventArgs) Handles TextBox2.Enter
        TextBox2.SelectAll()
        labUsed.Text = String.Empty
        labCharge.Text = String.Empty
     
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim u As Double
        Dim up As Double
        Dim uc As Double
        Dim total As Double

        If IsNumeric(TextBox1.Text()) = False Then
            MsgBox("Accept numbers only")
            TextBox1.Focus()
            ElseIf IsNumeric(TextBox2.Text()) = False Then
                MsgBox("Accept numbers only")
            TextBox2.Focus()

        Else
            Double.TryParse(TextBox1.Text, uc)
            Double.TryParse(TextBox2.Text, up)

            u = uc - up

            total = u * 1.75 / 1000

            If total < 16.67 Then
                total = 16.67
            End If

            labUsed.Text = u.ToString("N2")
            labCharge.Text = total.ToString("C2")
        End If
         

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
