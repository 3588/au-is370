﻿' Name:         Shipping Project
' Purpose:      Display a shipping message
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtId_TextChanged(sender As Object, e As EventArgs) Handles txtId.TextChanged
        lblMsg.Text = String.Empty
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim strID As String
        strID = txtId.Text
        If strID.ToUpper = "TN" OrElse
             strID.ToUpper = "KY" OrElse
              strID.ToUpper = "IN" Then
            lblMsg.Text = "We ship to this state"
        Else
            lblMsg.Text = "We don't ship to this state"
        End If
    End Sub
End Class
