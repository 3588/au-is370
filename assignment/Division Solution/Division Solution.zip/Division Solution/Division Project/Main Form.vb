﻿' Name:         Division Project
' Purpose:      Displays the quotient after dividing
'               the larger number by the smaller number
' Programmer:  <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearLabel(sender As Object, e As EventArgs) Handles txtNum1.TextChanged, txtNum2.TextChanged
        lblQuotient.Text = String.Empty
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim fnumber As Double
        Dim snumber As Double
        Dim temp As Double
        Dim quotient As Double
        Double.TryParse(txtNum1.Text, fnumber)
        Double.TryParse(txtNum2.Text, snumber)
        If (fnumber < snumber) Then
            temp = fnumber
            fnumber = snumber
            snumber = temp
        End If
        If fnumber <> 0 And snumber <> 0 Then
            quotient = fnumber / snumber
            lblQuotient.Text = quotient.ToString("N2")
        Else
            MessageBox.Show("Cannot divide by 0")
            txtNum1.Focus()
        End If

    End Sub
End Class
