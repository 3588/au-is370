﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Private Sub tboxQuantity_Enter(sender As Object, e As EventArgs) Handles tboxQuantity.Enter
        labDisc.Text = String.Empty
        labDue.Text = String.Empty
    End Sub
    Private Sub tboxPrice_Enter(sender As Object, e As EventArgs) Handles tboxPrice.Enter
        labDisc.Text = String.Empty
        labDue.Text = String.Empty
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dlgbu As DialogResult
        Dim dic As Double
        Dim q As Double
        Dim p As Double
        Dim due As Double
        dlgbu = MessageBox.Show("Are you a wholesaler?", "sholesalers", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If dlgbu = Windows.Forms.DialogResult.Yes Then
            dic = 0.1
        End If

        Double.TryParse(tboxQuantity.Text, q)
        Double.TryParse(tboxPrice.Text, p)
        dic = q * p * dic
        due = q * p - dic
        labDisc.Text = dic.ToString("C2")
        labDue.Text = due.ToString("C2")

    End Sub
End Class
