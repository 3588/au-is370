﻿Option Explicit On
Option Strict On
Option Infer Off
Public Class Form1
    Public yes As Integer
    Public no As Integer
    Public operation As Integer '0 = add 1 = sub
    Public e As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'init
        GroupBox2.Text = "Levels"
        GroupBox3.Text = "Operation"
        GroupBox4.Visible = False
        RadioButton1.Text = "Level 1( 1 - 10)"
        RadioButton2.Text = "Level 2( 10 - 100)"
        RadioButton3.Text = "Addition"
        RadioButton4.Text = "Subtraction"
        Label3.Text = "Correct"
        Label4.Text = "Incorrect"
        CheckBox1.Text = "Display Results"
        PictureBox1.Image = My.Resources.Resources.add
        PictureBox2.Image = My.Resources.Resources.e
        yes = 0
        no = 0
        operation = 0
        showResults()
        initRuns()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        initRuns()
    End Sub
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        initRunb()
    End Sub


    Private Sub initRuns()
        Dim n1 As Integer
        Dim n2 As Integer
        Dim randGen As New Random
        n1 = randGen.Next(1, 11)
        n2 = randGen.Next(1, 11)
        Label1.Text = n1.ToString
        Label2.Text = n2.ToString

    End Sub
    Private Sub initRunb()
        Dim n1 As Integer
        Dim n2 As Integer
        Dim randGen As New Random
        n1 = randGen.Next(10, 101)
        n2 = randGen.Next(10, 101)
        Label1.Text = n1.ToString
        Label2.Text = n2.ToString

    End Sub
    Private Sub showResults()
        Label5.Text = yes.ToString
        Label6.Text = no.ToString
    End Sub


    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        operation = 0
        PictureBox1.Image = My.Resources.Resources.add
        If (RadioButton1.Checked) Then
            initRuns()
        Else
            initRunb()
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        operation = 1
        PictureBox1.Image = My.Resources.Resources._sub

        If (RadioButton1.Checked) Then
            initRuns()
        Else
            initRunb()
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        GroupBox4.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim gete As Integer
        Dim syse As Integer
        Dim n1 As Integer
        Dim n2 As Integer
      
            Integer.TryParse(Label1.Text, n1)
            Integer.TryParse(Label2.Text, n2)
            Integer.TryParse(TextBox1.Text, gete)
            If (operation = 0) Then
                syse = n1 + n2
            Else
            syse = n1 - n2
        End If

        If (gete = syse) Then
            isyes()
        Else
            isno()
        End If

    End Sub

    Private Sub TextBox1_Enter(sender As Object, e As EventArgs) Handles TextBox1.Enter
        TextBox1.SelectAll()
    End Sub
    Private Sub isyes()
        PictureBox3.Image = My.Resources.Resources.yes
        yes = yes + 1
        Label5.Text = yes.ToString
        If (RadioButton1.Checked) Then
            initRuns()
        Else
            initRunb()
        End If
    End Sub
    Private Sub isno()
        PictureBox3.Image = My.Resources.Resources.no
        no = no + 1
        Label6.Text = no.ToString
        MessageBox.Show("Try again!", "Math Practice", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown


        If e.KeyCode = Keys.Return Then
            Button1_Click(sender, e)
        End If

    End Sub
End Class
