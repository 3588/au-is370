﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.labSubtotal = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.labTax = New System.Windows.Forms.Label()
        Me.labShip = New System.Windows.Forms.Label()
        Me.labDue = New System.Windows.Forms.Label()
        Me.tboxPrice = New System.Windows.Forms.TextBox()
        Me.butCalculate = New System.Windows.Forms.Button()
        Me.butExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(137, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "&Item price:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.labDue)
        Me.GroupBox1.Controls.Add(Me.labShip)
        Me.GroupBox1.Controls.Add(Me.labTax)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.labSubtotal)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(49, 133)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(235, 155)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Subtotal"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(34, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Sales tax"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(34, 98)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Shipping"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(34, 124)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total due"
        '
        'labSubtotal
        '
        Me.labSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labSubtotal.Location = New System.Drawing.Point(119, 34)
        Me.labSubtotal.Name = "labSubtotal"
        Me.labSubtotal.Size = New System.Drawing.Size(68, 13)
        Me.labSubtotal.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(98, 71)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 13)
        Me.Label7.TabIndex = 6
        '
        'labTax
        '
        Me.labTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labTax.Location = New System.Drawing.Point(119, 68)
        Me.labTax.Name = "labTax"
        Me.labTax.Size = New System.Drawing.Size(68, 13)
        Me.labTax.TabIndex = 7
        '
        'labShip
        '
        Me.labShip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labShip.Location = New System.Drawing.Point(119, 97)
        Me.labShip.Name = "labShip"
        Me.labShip.Size = New System.Drawing.Size(68, 13)
        Me.labShip.TabIndex = 8
        '
        'labDue
        '
        Me.labDue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labDue.Location = New System.Drawing.Point(119, 124)
        Me.labDue.Name = "labDue"
        Me.labDue.Size = New System.Drawing.Size(68, 13)
        Me.labDue.TabIndex = 9
        '
        'tboxPrice
        '
        Me.tboxPrice.Location = New System.Drawing.Point(117, 66)
        Me.tboxPrice.Name = "tboxPrice"
        Me.tboxPrice.Size = New System.Drawing.Size(100, 20)
        Me.tboxPrice.TabIndex = 2
        '
        'butCalculate
        '
        Me.butCalculate.Location = New System.Drawing.Point(86, 295)
        Me.butCalculate.Name = "butCalculate"
        Me.butCalculate.Size = New System.Drawing.Size(75, 23)
        Me.butCalculate.TabIndex = 3
        Me.butCalculate.Text = "&Calculate"
        Me.butCalculate.UseVisualStyleBackColor = True
        '
        'butExit
        '
        Me.butExit.Location = New System.Drawing.Point(188, 295)
        Me.butExit.Name = "butExit"
        Me.butExit.Size = New System.Drawing.Size(75, 23)
        Me.butExit.TabIndex = 4
        Me.butExit.Text = "E&xit"
        Me.butExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(317, 343)
        Me.Controls.Add(Me.butExit)
        Me.Controls.Add(Me.butCalculate)
        Me.Controls.Add(Me.tboxPrice)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Treasures"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents labDue As System.Windows.Forms.Label
    Friend WithEvents labShip As System.Windows.Forms.Label
    Friend WithEvents labTax As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents labSubtotal As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tboxPrice As System.Windows.Forms.TextBox
    Friend WithEvents butCalculate As System.Windows.Forms.Button
    Friend WithEvents butExit As System.Windows.Forms.Button

End Class
