﻿Public Class Form1
    Dim subtotal As Double
    Private Sub butExit_Click(sender As Object, e As EventArgs) Handles butExit.Click
        Me.Close()
    End Sub

    Private Sub butCalculate_Click(sender As Object, e As EventArgs) Handles butCalculate.Click
        Dim itemPrice As Double
        Double.TryParse(tboxPrice.Text, itemPrice)
        subtotal = subtotal + itemPrice
        labSubtotal.Text = subtotal.ToString("C2")

        Dim tax As Double
        tax = subtotal * 0.02
        labTax.Text = tax.ToString("C2")

        Dim ship As Double
        If (subtotal > 100) Then
            ship = 0.0
        Else
            ship = 10.0
        End If

        labShip.Text = ship.ToString("C2")
        Dim out As Double
        out = subtotal + ship + tax
        labDue.Text = out.ToString("C2")


    End Sub
End Class
