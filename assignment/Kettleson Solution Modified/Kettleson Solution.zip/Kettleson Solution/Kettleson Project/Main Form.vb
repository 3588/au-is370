﻿' Name:         Kettleson Project
' Purpose:      Display a bonus amount
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtSales_Enter(sender As Object, e As EventArgs) Handles txtSales.Enter
        txtSales.SelectAll()
    End Sub

    Private Sub txtSales_TextChanged(sender As Object, e As EventArgs) Handles txtSales.TextChanged
gogo:
        lblBonus.Text = String.Empty
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calculates and displays a bonus 

        If IsNumeric(txtSales.Text()) = False Then
            MsgBox("Accept numbers only")
            txtSales.Focus()
        Else

            Dim dblSales As Double
            Dim dblBonus As Double

            Double.TryParse(txtSales.Text, dblSales)

            If dblSales > 15000 And dblSales < 25000.01 Then
                dblBonus = dblSales * 0.02
            ElseIf dblSales > 25000 And dblSales < 50000.01 Then
                dblBonus = dblSales * 0.03
            ElseIf dblSales > 50000 Then
                dblBonus = dblSales * 0.04
            ElseIf dblSales < 15000.01 Then
                dblBonus = dblSales * 0.015
            End If

            lblBonus.Text = dblBonus.ToString("C2")

        End If

    End Sub
End Class
