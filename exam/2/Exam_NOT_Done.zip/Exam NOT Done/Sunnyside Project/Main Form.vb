' Name:         Sunnyside Project
' Purpose:      Displays the total price of an order
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtUnits_Enter(sender As Object, e As EventArgs) Handles txtUnits.Enter
        txtUnits.SelectAll()
    End Sub

    Private Sub txtUnits_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUnits.KeyPress
        ' accept only numbers and the Backspace key

        If (e.KeyChar < "3" OrElse e.KeyChar > "4") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub ClearLabel(sender As Object, e As EventArgs
                           ) Handles txtUnits.TextChanged, radRetailer.Click, radWholesaler.Click
        lblOrder.Text = String.Empty
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calculates the total price of an order

        Dim intUnits As Integer
        Dim intUnitPrice As Integer
        Dim intTotalPrice As Integer

        Integer.TryParse(txtUnits.Text, intUnits)

     

        intTotalPrice = intUnits * intUnitPrice

        txtUnits.Focus()
    End Sub
End Class
